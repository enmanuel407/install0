#!/bin/sh


DIR="$HOME/.config/polybar/cuts"


# Launch the bar
polybar -q tray -c "$DIR"/config-2.ini &
