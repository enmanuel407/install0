#/usr/bin/zsh

rofi -dmenu -p "Search-URL:" | xargs -I{} google-chrome {\}
