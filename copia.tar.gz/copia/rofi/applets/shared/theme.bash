## Current Theme

type="$HOME/.config/rofi/applets/type-3"
style='style-3.rasi'
