#/usr/bin/zsh

rofi -dmenu -p "Search-YouCode:" | xargs -I{} google-chrome https://you.com/search?q={\}"&"fromSearchBar=true"&"tbm=youchat
