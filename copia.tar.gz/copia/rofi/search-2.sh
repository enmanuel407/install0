#/usr/bin/zsh

rofi -dmenu -p "Search-Google:" | xargs -I{} google-chrome --incognito https://www.google.de/search\?q\=\{\}
