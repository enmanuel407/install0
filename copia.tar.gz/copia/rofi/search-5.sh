#/usr/bin/zsh

rofi -dmenu -p "Search-Perplexity:" | xargs -I{} google-chrome https://www.perplexity.ai/search?q={\}
