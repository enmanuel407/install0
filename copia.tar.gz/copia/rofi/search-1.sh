#/usr/bin/zsh

rofi -dmenu -p "Search-Google:" | xargs -I{} google-chrome https://www.google.de/search\?q\=\{\}
